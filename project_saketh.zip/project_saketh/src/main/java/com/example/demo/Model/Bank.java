package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Bank {
	
	@Id
	private String bic;
	private String bankName;
	
}
