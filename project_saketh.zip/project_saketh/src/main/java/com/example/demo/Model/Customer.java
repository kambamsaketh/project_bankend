package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Customer {
	
	@Id
	private Long customerId;
	private String customerName;
	private Boolean overDraftFlag;
	private Double clearBalance;
	
}
