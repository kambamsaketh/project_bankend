package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.Bank;
import com.example.demo.Repository.BankRepository;

@Service
@Transactional
public class BankService {
	
	@Autowired
	private BankRepository bankRepository;
	
	public List<Bank> showBanks() {
		return bankRepository.findAll();
	}
	
	public Bank findBank(String bic) {
		return bankRepository.findById(bic).get();
	}
	
	public String addBank(Bank bank) {
		bankRepository.save(bank);
		return "Saved";
	}
	
	public String deleteBank(Bank bank) {
		bankRepository.delete(bank);
		return "Deleted";
	}
	
}
