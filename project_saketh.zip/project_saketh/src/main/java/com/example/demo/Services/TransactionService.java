package com.example.demo.Services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Currency;
import com.example.demo.Model.Customer;
import com.example.demo.Model.Transaction;
import com.example.demo.Repository.CurrencyRepository;
import com.example.demo.Repository.CustomerRepository;
import com.example.demo.Repository.TransactionRepository;

@Service
public class TransactionService {
	
	@Autowired
	private TransactionRepository transactionRepository;
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private CurrencyRepository currencyRepository;
	
	public List<Transaction> showTransactions(){
		return transactionRepository.findAll();
	}
	
	public Transaction findTransaction(Long transactionId) {
		return transactionRepository.findById(transactionId).get();
	}
	
	public boolean checkReceiverName(String banString) throws IOException {
		File file = new File("./src/main/resources/sdnlist.txt");
		try(BufferedReader br=new BufferedReader(new FileReader(file))){
			String st;
			Set<String> data=new HashSet<>();
			while ((st = br.readLine()) != null){
				java.util.List<String> lineData=Arrays.asList(st.split("[-+\\/.,; \"()@]"));
				lineData=lower(lineData);
				data.addAll(lineData);
			}
			java.util.List<String> nameSplit=Arrays.asList(banString.split("[-+\\/.,; \"()@]"));
			nameSplit=lower(nameSplit);
			for(String s:nameSplit){
				if(!data.contains(s)){
					return(false);
				}
			}
		}
		return(true);
	}
	
	private static java.util.List<String> lower(java.util.List<String> names) {
		return names.stream().map((name)->name.toLowerCase()).collect(Collectors.toList());
	}


	
	public String addTransaction(Transaction transaction) throws IOException {
		String banString = transaction.getRecieverAccountholderName();
		if(!checkReceiverName(banString)) {
			Currency currency = currencyRepository.findById(transaction.getCurrency().getCurrencyCode()).get();
			transaction.setCurrency(currency);
			transaction.setInramount(transaction.getCurrencyAmount()*transaction.getCurrency().getConversionRate());
			Customer customer = customerRepository.findById(transaction.getCustomers().getCustomerId()).get();
			customer.setClearBalance(customer.getClearBalance()-transaction.getInramount());
			Customer customer2 = customerRepository.findById(transaction.getRecieverAccountholderNumber()).get();
			customer2.setClearBalance(customer2.getClearBalance()+transaction.getInramount());
			transaction.setCustomers(customer);
			Date date = new Date();
			transaction.setDate(date);
			transactionRepository.save(transaction);
			return "Saved";
		}
		else {
			return "Cannot";
		}
	}

}
