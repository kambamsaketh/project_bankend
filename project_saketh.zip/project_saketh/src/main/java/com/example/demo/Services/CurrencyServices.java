package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Currency;
import com.example.demo.Repository.CurrencyRepository;

@Service
public class CurrencyServices {

	@Autowired
	private CurrencyRepository currencyRepository;
	
	public List<Currency> showCurrencies(){
		return currencyRepository.findAll();
	}
	
	public Currency findCurrency(String currencyCode) {
		return currencyRepository.findById(currencyCode).get();
	}
	
	public String addCurrency(Currency currency) {
		currencyRepository.save(currency);
		return "saved"; 
	}
	
}
