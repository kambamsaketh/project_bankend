package com.example.demo.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Currency;
import com.example.demo.Services.CurrencyServices;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/currency")
public class CurrencyRestController {
	
	@Autowired
	private CurrencyServices currencyServices;
	
	@GetMapping("/lst")
	public List<Currency> showCurrencies(){
		return currencyServices.showCurrencies();
	}
	
	@GetMapping("/lst/{currencyCode}")
	public Currency findCurrency(@PathVariable String currencyCode) {
		return currencyServices.findCurrency(currencyCode);
	}
	
	@PostMapping("/add")
	public String addCurrency(@RequestBody Currency currency) {
		return currencyServices.addCurrency(currency);
	}
}
