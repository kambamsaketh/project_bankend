package com.example.demo.RestController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRepository {
	@GetMapping("/")
	public String greetings() {
		return "Good Morning";
	}
}
