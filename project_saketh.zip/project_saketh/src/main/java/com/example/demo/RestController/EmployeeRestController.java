package com.example.demo.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Employee;
import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.Services.EmployeeServices;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/employee")
public class EmployeeRestController {

	@Autowired
	private EmployeeServices employeeServices;
	
	@GetMapping("/lst")
	public List<Employee> showEmployees(){
		return employeeServices.showEmployees();
	}
	
	@GetMapping("/lst/{employeeId}")
	public Employee findEmployee(@PathVariable Long employeeId) {
		return employeeServices.findEmployee(employeeId);
	}
	
	@PostMapping("/add")
	public String addEmployee(@RequestBody Employee employee) {
		return employeeServices.addEmployee(employee);
	}
	
}
