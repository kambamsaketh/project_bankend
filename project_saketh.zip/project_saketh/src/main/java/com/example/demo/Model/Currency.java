package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Currency {

	@Id
	private String currencyCode;
	private Double conversionRate;
	
}
