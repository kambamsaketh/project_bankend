package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Employee;
import com.example.demo.Repository.EmployeeRepository;

@Service
public class EmployeeServices {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	public List<Employee> showEmployees(){
		return employeeRepository.findAll();
	}
	
	public Employee findEmployee(Long employeeId) {
		return employeeRepository.findById(employeeId).get();
	}
	
	public String addEmployee(Employee employee) {
		employeeRepository.save(employee);
		return "Saved";
	}
	
}
