package com.example.demo.RestController;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Customer;
import com.example.demo.Services.CustomerService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/customer")
public class CustomerRestController {

private static final Logger log = LoggerFactory.getLogger(CustomerRestController.class);

	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/lst")
	public List<Customer> showCustomers(){
		return customerService.showCustomers();
	}
	
	@GetMapping("/balance/{customerId}")
	public Double showBalance(@PathVariable Long customerId) {
		return customerService.findCustomer(customerId).getClearBalance();
	}
	
	@GetMapping("/lst/{customerId}")
	public Customer findCustomer(@PathVariable Long customerId) {
		return customerService.findCustomer(customerId);
	}
	
	@PostMapping("/add")
	public String addCustomer(@RequestBody Customer customer) {
		log.info("Data to be saved :"+customer);
		return customerService.addCustomer(customer);
	}
	
	@PutMapping("/update")
	public String updateCustomer(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer);
	}
	
	@DeleteMapping("/delete")
	public String deleteCustomer(@RequestBody Customer customer) {
		return customerService.deleteCustomer(customer);
	}
	
}
