package com.example.demo.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Bank;
import com.example.demo.Services.BankService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/bank")
public class BankRestController {

	@Autowired
	private BankService bankService;
	
	@GetMapping("/lst")
	public List<Bank> showBanks(){
		return bankService.showBanks();
	}
	
	@GetMapping("/lst/{bic}")
	public Bank findBank(@PathVariable String bic) {
		return bankService.findBank(bic);
	}
	
	@PostMapping("/add")
	public String addBank(@RequestBody Bank bank) {
		return bankService.addBank(bank);
	}
	
	@DeleteMapping("/delete")
	public String deleteBank(@RequestBody Bank bank) {
		return bankService.deleteBank(bank);
	}
	
}