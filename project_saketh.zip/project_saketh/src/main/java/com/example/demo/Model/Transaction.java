package com.example.demo.Model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

@Entity
@Data
public class Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long transactionId;
	private String senderBic;
	private String recieverBic;
	private Long recieverAccountholderNumber;
	private String recieverAccountholderName;
	private Double currencyAmount;
	private Double inramount;
	private Date date;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customerId")
	private Customer customers;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "currencyCode")
	private Currency currency;
	
}
