package com.example.demo.Services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.Customer;
import com.example.demo.Repository.CustomerRepository;

@Service
@Transactional
public class CustomerService {
	
	private static final Logger log = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	private CustomerRepository customerRepository;
	
	public List<Customer> showCustomers(){
		return customerRepository.findAll();
	}
	
	public Customer findCustomer(Long customerId) {
		return customerRepository.findById(customerId).get();
	}
	
	public String addCustomer(Customer customer) {
		log.info("Object :"+customer);
		customerRepository.save(customer);
		return "Saved";
	}
	
	public String updateCustomer(Customer customer) {
		customerRepository.save(customer);
		return "Updated";
	}
	
	public String deleteCustomer(Customer customer) {
		customerRepository.delete(customer);
		return "Deleted";
	}
	
}
