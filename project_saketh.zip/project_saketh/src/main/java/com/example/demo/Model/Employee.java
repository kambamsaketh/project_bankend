package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Employee {

	@Id
	private Long employeeId;
	private String employeePassword;
	
}