package com.example.demo.RestController;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Transaction;
import com.example.demo.Services.TransactionService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/transaction")
public class TransactionRestController {

	@Autowired
	private TransactionService transactionService;
	
	@GetMapping("/lst")
	public List<Transaction> showCustomers(){
		return transactionService.showTransactions();
	}
	
	@GetMapping("/lst/{transactionId}")
	public Transaction findTransaction(@PathVariable Long transactionId) {
		return transactionService.findTransaction(transactionId);
	}
	
	@PutMapping("/add")
	public String addTransaction(@RequestBody Transaction transaction) throws IOException {
		return transactionService.addTransaction(transaction);
	}
	
}
