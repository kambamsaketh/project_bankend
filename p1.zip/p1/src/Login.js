import React, {useState} from 'react'
import { useNavigate } from 'react-router'
import axios from 'axios';
import './Login.css';
import { Button } from 'primereact/button';
import { Toolbar } from 'primereact/toolbar';
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { Link } from 'react-router-dom';


const Login = () => {
  const [userId, setUserId] = useState("")
  const [password, setPassword] = useState("")
  const [loginValue, setLoginValue] = useState(false)
  const navigate = useNavigate()

  const showLogin = (e) => {

    e.preventDefault()
    setLoginValue(true)
  }

  const handleUserIdChange = (e) => {
    setUserId(e.target.value)
  }

  const handlePasswordChange = (e) => {
    setPassword(e.target.value)
  }
  
  const rightContents = (
    <React.Fragment>
      <Button label="Login" className="p-button-danger p-button-text" onClick={showLogin} />
    </React.Fragment>
  );

  const routetohome=()=>{
    localStorage.setItem("verify","true")
    navigate('/home')
    
  }

  const handleSubmit = () => {
    axios.get("http://localhost:8080/employee/lst/"+userId)
    .then(res=>{
      const result=((res.data.employeePassword==password) && (res.data.employeeId==userId))
      if(result){
        routetohome()
      }
      else{
        alert("Wrong userId or password")
        navigate("/")
      }
    })
    .catch(err => {
      alert("Could not fetch employee")
    })
  }
  
  return (
    <div>
      <Toolbar  right={rightContents} />
      
      <Splitter style={{height: '300px'}}>
        <SplitterPanel>
        <p>DBS is a leading financial services group in Asia with a presence in 18 markets. Headquartered and listed in Singapore, DBS is in the three key Asian axes of growth: Greater China, Southeast Asia and South Asia.</p>
        <p>DBS provides a full range of services in consumer, SME and corporate banking. As a bank born and bred in Asia, DBS understands the intricacies of doing business in the region’s most dynamic markets. DBS is committed to building lasting relationships with customers, and positively impacting communities through supporting social enterprises, as it banks the Asian way. It has also established a SGD 50 million foundation to strengthen its corporate social responsibility efforts in Singapore and across Asia.</p>
      </SplitterPanel>
      <SplitterPanel className="m1">
        {loginValue && <div><form>
          <label for="userId">User ID : </label><br/><br/>
          <InputText value={userId} onChange={handleUserIdChange} placeholder="Enter User ID" />
            <br/><br/>
            <label for="password">Password : </label><br/><br/>
            <Password value={password} onChange={handlePasswordChange} feedback={false} placeholder="Enter Password" />
            <br/><br/>
            {/* <Button label="Submit"  onClick={handleSubmit}></Button> */}
            <Button><Link to="" onClick={handleSubmit}>Submit</Link></Button>
        </form></div>}
    </SplitterPanel>
</Splitter>
    </div>
  );
}

export default Login