import React,{useState} from 'react'
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { Splitter, SplitterPanel } from 'primereact/splitter';
import './Home.css'
import { Toolbar } from 'primereact/toolbar';
import { useNavigate } from 'react-router'
import { InputText } from 'primereact/inputtext';
import axios from "axios"
import { Link } from 'react-router-dom';

const Home = () => {

    const navigate = useNavigate();

    if(localStorage.getItem("verify") != "true"){
        navigate("/")
    }

    const [accNo,setAccNo] = useState("")
    const [balanceTab,setBalanceTab] = useState(false)

    const handleAccNoChange = (e) => {
        setAccNo(e.target.value)
    }

    const handleGetBalance = ()=>{
        axios.get("http://localhost:8080/customer/balance/"+accNo)
        .then(res => {
            alert("Balance = "+res.data)
            setBalanceTab(false)
            setAccNo("")
        })
        .catch(err => {
            alert("Customer does not exist")
            setBalanceTab(false)
        })
    }

    const handleBalanceTab = ()=>{
        if(localStorage.getItem("verify") != "true"){
            navigate("/")
        }
        setBalanceTab(true)
    }

    const handleTransfer = () => {
        
        navigate('/transfer')

    }

    const footerCheckBalance = (
        <span>
            <Button label="Check Balance" className="p-button-success p-button-text" onClick={handleBalanceTab} />
        </span>
    );

    const footerTransferMoney = (
        <span>
            <Button label="Transfer" className="p-button-success p-button-text" onClick={handleTransfer} />
        </span>
    )

    const footerBalance = (
        <span>
            <form>
                <label >Enter Account Number : </label><br/><br/>
                <InputText value={accNo} onChange={handleAccNoChange} placeholder="Enter Account Number" />
                <br/><br/>
                {/* <Button label="Get Balance"  onClick={handleGetBalance}></Button> */}
                <Button><Link to="" onClick={handleGetBalance}>Get Balance</Link></Button>
            </form>
        </span>
    )

    const handleTransactionHistory = () => {
        navigate("/transactionhistory")
    }

    const footerHistory = (
        <span>
            <Button label="History" className="p-button-success p-button-text" onClick={handleTransactionHistory} />
        </span>
    )

    const handleLogOut = () => {
        localStorage.removeItem("verify")
        navigate('/')
    }

    const rightContents = (
        <React.Fragment>
          <Button label="Logout" className="p-button-danger p-button-text" onClick={handleLogOut} />
        </React.Fragment>
      );
    
    return(
        <div>
            <Toolbar  right={rightContents} />
            <Splitter style={{height: '300px'}} className="m2">
                <SplitterPanel>
                    <Card title="Check Balance" style={{ width: '25em' }} footer={footerCheckBalance}></Card>
                </SplitterPanel>
                <SplitterPanel>
                    <Card title="Transfer Money" style={{ width: '25em' }} footer={footerTransferMoney}></Card>
                </SplitterPanel>
                <SplitterPanel>
                    <Card title="Transaction History" style={{ width: '25em' }} footer={footerHistory}></Card>
                </SplitterPanel>
            </Splitter>
            {balanceTab && <Splitter style={{height: '300px'}} className="m2">
                <SplitterPanel>
                    <Card title="Check Balance" style={{ width: '25em' }} footer={footerBalance}></Card>
                </SplitterPanel>
            </Splitter>}
        </div>
    )

}

export default Home