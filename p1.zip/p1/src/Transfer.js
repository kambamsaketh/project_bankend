import React, {useState,useEffect} from 'react'
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import axios from 'axios'
import { Toolbar } from 'primereact/toolbar';
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { useNavigate } from 'react-router'
import './Transfer.css'
import { Link } from 'react-router-dom';
import { Dropdown } from 'primereact/dropdown';

const Transfer = () => {

    const navigate = useNavigate();

    if(localStorage.getItem("verify") != "true"){
        navigate("/")
    }

    const [senderAccno, setSenderAccno] = useState("")
    const [senderBic, setSenderBic] = useState("")
    const [senderBankName, setSenderBankname] = useState("")
    const [senderBank, setSenderBank] = useState(false)
    const [senderName, setSenderName] = useState("")
    const [recieverAccno, setRecieverAccNo] = useState("")
    const [recieverName, setRecieverName] = useState("")
    const [recieverBic, setRecieverBic] = useState("")
    const [recieverBankName, setRecieverBankName] = useState("")
    const [recieverBank,setRecieverBank] = useState(false)
    const [firstNext, setFirstNext] = useState(true)
    const [secondNext, setSecondNext] = useState(false)
    const [currency, setCurrency] = useState("")
    const [amount,setAmount] = useState("")

    useEffect(() => {
        axios.get("http://localhost:8080/customer/lst/"+senderAccno)
        .then(res => setSenderName(res.data.customerName))
        .catch(err => {
            alert("Could not fetch customers")
            setSenderName("")
        })
    },[senderAccno])

    useEffect(() => {
        axios.get("http://localhost:8080/customer/lst/"+recieverAccno)
        .then(res => setRecieverName(res.data.customerName))
        .catch(err => {
            alert("Could not fetch customers")
            setRecieverName("")
        })
    },[recieverAccno])

    useEffect(() => {
        axios.get("http://localhost:8080/bank/lst/"+senderBic)
        .then(res => setSenderBankname(res.data.bankName))
        .catch(err => {
            alert("Could not fetch customers")
            setSenderBankname("")
    })
    },[senderBic])

    useEffect(() => {
        axios.get("http://localhost:8080/bank/lst/"+recieverBic)
        .then(res => setRecieverBankName(res.data.bankName))
        .catch(err => {
            alert("Could not fetch customers")
            setRecieverBankName("")
        })
    },[recieverBic])

    const showLogout = () => {
        localStorage.removeItem("verify")
        navigate('/')
        
    }

    const showHome = () => {
        
        navigate('/home')
        
    }

    const rightContents = (
        <React.Fragment>
            <Button label="Back to Home" className="p-button-success p-button-text" onClick={showHome} />
          <Button label="Logout" className="p-button-danger p-button-text" onClick={showLogout} />
        </React.Fragment>
      );

    const handleSenderAccno = (e) => {
        setSenderAccno(e.target.value)
    }

    const handleRecieverAccno = (e) => {
        setRecieverAccNo(e.target.value)
    }

    const handleSenderName = (e) => {
        setSenderName(e.target.value)
    }

    const handleRecieverName = (e) => {
        setRecieverName(e.target.value)
    }

    const handleSenderBic = (e) => {
        setSenderBic(e.target.value)
    }

    const handleRecieverBic = (e) => {
        setRecieverBic(e.target.value)
    }

    const handleBankNameChange = (e) => {
        setSenderBankname(e.target.value)
    }

    const handleRecieverBankNameChange= (e) => {
        setRecieverBankName(e.target.value)
    }

    const handleSenderNext = () => {

        axios.get("http://localhost:8080/customer/lst/"+senderAccno)
        .then(res=>{
            if((res.data.customerId == senderAccno) && (res.data.customerName == senderName) ){

                axios.get("http://localhost:8080/bank/lst/"+senderBic)
                .then(res => {
                    if((res.data.bic == senderBic) && (res.data.bankName == senderBankName)){
                        setSenderBank(true)
                        setFirstNext(false)
                        setSecondNext(true)
                    }
                    else{
                        alert("Sender BIC and Sender Bank Name does not match")
                    }
                })
                .catch(err => alert("Could not fetch bank details"))

            }
            else{
                alert("Sender ID and Sender Name does not match")
            }
        })
        .catch(err => alert("Could not fetch customer details"))
        
    }

    const handleRecieverNext = () => {

        if(senderAccno != recieverAccno){

            axios.get("http://localhost:8080/customer/lst/"+recieverAccno)
            .then(res=>{
                if((res.data.customerId == recieverAccno) && (res.data.customerName == recieverName) ){

                    axios.get("http://localhost:8080/bank/lst/"+recieverBic)
                    .then(res => {
                    if((res.data.bic == recieverBic) && (res.data.bankName == recieverBankName)){
                        setRecieverBank(true)
                        setSecondNext(false)
                    }
                    else{
                        alert("Reciever BIC and Reciever Bank Name does not match")
                    }
                })
            .catch(err => alert("Could not fetch bank details"))

            }
            else{
                alert("Reciever ID and Reciever Name does not match")
            }
        })
        .catch(err => alert("Could not fetch customer details"))
    }
    else{
        alert("Sender and Reciever Account Numbers should not be same")
        setRecieverAccNo("")
        setRecieverName("")
        setRecieverBic("")
        setRecieverBankName("")
    }
        
    }
    
    const CurrencyItems = [
        {label: 'USD', value: 'USD'},
        {label: 'INR', value: 'INR'},
        {label: 'EUR', value: 'EUR'},
        {label: 'GBP', value: 'GBP'},
        {label: 'JPY', value: 'JPY'}
    ];

    const handleCurrency= (e) => {
        setCurrency(e.target.value)
    }

    const handleAmount =(e) => {
        setAmount(e.target.value)
    }

    const handleTransfer = () => {
        const transfer = {
            "senderBic" : senderBic,
            "recieverBic" : recieverBic,
            "recieverAccountholderNumber" : recieverAccno,
            "recieverAccountholderName" : recieverName,
            "currencyAmount" : amount,
            "customers" : {"customerId" : senderAccno},
            "currency" : {"currencyCode" : currency}
        }
        axios.get("http://localhost:8080/customer/lst/"+senderAccno)
        .then(res => {
            axios.get("http://localhost:8080/currency/lst/"+currency)
            .then(res2 => {
                if((parseFloat(amount)*res2.data.conversionRate <= res.data.clearBalance) || ((res.data.overDraftFlag) && ((parseFloat(amount)*res2.data.conversionRate-res.data.clearBalance) <= 10000 )) ){
                    axios.put("http://localhost:8080/transaction/add",transfer)
                    .then(res => {
                        if(res.data==="Cannot"){
                            alert("Cannot do transaction because reciever is block listed")
                            navigate("/home")
                        }
                        else{
                        alert("Transaction Successfull")
                        navigate("/home")}

                    })
                    .catch(err => {
                        alert("Error")
                    })
                }
                else{
                    alert("Cannot Transfer because of Low Balance")
                    navigate("/home")
                }
            })
        })

    }

    return(
        <div>

            <Toolbar  right={rightContents} /> 

            <Splitter style={{height: '300px'}}>
                <SplitterPanel className="m5">
                    <div>
                        <form>
                            <label for="senderAccno">Sender Account Number : </label><br/><br/>
                            <InputText value={senderAccno} onChange={handleSenderAccno} placeholder="Enter Sender Account Number" />
                            <br/><br/>
                            <label for="senderName">Sender Name : </label><br/><br/>
                            <InputText value={senderName} onChange={handleSenderName} placeholder="Enter Sender Name" />
                            <br/><br/>
                            <label for="senderBic">Sender BIC : </label><br/><br/>
                            <InputText value={senderBic} onChange={handleSenderBic} placeholder="Enter Sender BIC" />
                            <br/><br/>
                            <label for="senderBankName">Sender Bank Name : </label><br/><br/>
                            <InputText value={senderBankName} onChange={handleBankNameChange} placeholder="Enter Sender Bank Name" />
                            <br/><br/>
                            {firstNext && <Button><Link to="" onClick={handleSenderNext}>Next</Link></Button>}
                        </form>
                    </div>
                </SplitterPanel>
                <SplitterPanel className="m5">
                    {senderBank && 
                        <div>
                            <form>
                                <label for="recieverAccno">Reciever Account Number : </label><br/><br/>
                            <InputText value={recieverAccno} onChange={handleRecieverAccno} placeholder="Enter Reciever Account Number" />
                            <br/><br/>
                            <label for="recieverName">Reciever Name : </label><br/><br/>
                            <InputText value={recieverName} onChange={handleRecieverName} placeholder="Enter Reciever Name" />
                            <br/><br/>
                            <label for="recieverBic">Reciever BIC : </label><br/><br/>
                            <InputText value={recieverBic} onChange={handleRecieverBic} placeholder="Enter Reciever BIC" />
                            <br/><br/>
                            <label for="recieverBankName">Reciever Bank Name : </label><br/><br/>
                            <InputText value={recieverBankName} onChange={handleRecieverBankNameChange} placeholder="Enter Reciever Bank Name" />
                            <br/><br/>
                            {secondNext && <Button><Link to="" onClick={handleRecieverNext}>Next</Link></Button>}
                        </form>
                    </div>
                    }
                </SplitterPanel>
                <SplitterPanel className="m5">
                    {recieverBank && 
                        <div>
                            <label for="CurrencyCode">Select Currency Code : </label><br/><br/>
                            <Dropdown value={currency} options={CurrencyItems} onChange={handleCurrency} placeholder="Select Currency Code"/><br/><br/>
                            <label for="amount">Enter Amount : </label><br/><br/>
                            <InputText value={amount} onChange={handleAmount} placeholder="Enter Amount" /><br/><br/>
                            {!secondNext && <Button><Link to="" onClick={handleTransfer}>Transfer</Link></Button>}
                        </div>
                    }
                </SplitterPanel>
            </Splitter>
            
        </div>
    )
}

export default Transfer