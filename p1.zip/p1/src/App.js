import React from 'react'
import './App.css';
import Login from './Login';
import Home from './Home';
import { Routes, Route } from "react-router-dom";
import TransactionHistory from './TransactionHistory';
import Transfer from './Transfer';

function App() {
  
  return (
    <div>
      <Routes>
        <Route path="/" element={<Login/>} />
        <Route path="/home" element={<Home />} />
        <Route path="/transactionhistory" element={<TransactionHistory />} />
        <Route path="/transfer" element={<Transfer />} />
      </Routes>
    </div>
  );
}

export default App;
