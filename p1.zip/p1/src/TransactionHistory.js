import React, {useState, useEffect} from 'react'
import axios from 'axios'
import './TransactionHistory.css'
import { useNavigate } from 'react-router'
import { Button } from 'primereact/button';
import { Toolbar } from 'primereact/toolbar';

const TransactionHistory = () => {

    const navigate = useNavigate();

    if(localStorage.getItem("verify") != "true" ){
        navigate("/")
    }

    const [transactions, setTransactions] = useState([])
    

    useEffect( () => {
        axios.get("http://localhost:8080/transaction/lst")
        .then(res => setTransactions(res.data))
        .catch(err => alert("Could not fetch customers"))
    },[])

    const getTableTagsJSON = () => {
        
        const tableTags = transactions.map(t => {
            return (
                <tr key={t.transactionId}>
                    <td>{t.transactionId}</td>
                    <td>{t.customers.customerId}</td>
                    <td>{t.customers.customerName}</td>
                    <td>{t.senderBic}</td>
                    <td>{t.recieverAccountholderNumber}</td>
                    <td>{t.recieverAccountholderName}</td>
                    <td>{t.recieverBic}</td>
                    <td>{t.currency.currencyCode}</td>
                    <td>{t.currencyAmount}</td>
                    <td>{t.inramount}</td>
                    <td>{t.date}</td>
                </tr>
            )
        })
        return tableTags
    }

    const showLogout = () => {
        localStorage.removeItem("verify")
        navigate("/")
        
    }

    const showHome = () => {
        
        navigate("/home")
        
    }

    const rightContents = (
        <React.Fragment>
            <Button label="Back to Home" className="p-button-success p-button-text" onClick={showHome} />
          <Button label="Logout" className="p-button-danger p-button-text" onClick={showLogout} />
        </React.Fragment>
      );

    return(
        <div>
            <Toolbar  right={rightContents} />
            <h1>Transaction History :</h1>
            <table>
                <tr>
                    <th>Transaction Id</th>
                    <th>Sender Account Number</th>
                    <th>Sender Name</th>
                    <th>Sender BIC</th>
                    <th>Reciever Account Number</th>
                    <th>Reciever Name</th>
                    <th>Reciever BIC</th>
                    <th>Currency Code</th>
                    <th>Currency Amount</th>
                    <th>INR Amount</th>
                    <th>Date of Transaction</th>
                </tr>
                {getTableTagsJSON()}
            </table>
        </div>
    )

}

export default TransactionHistory